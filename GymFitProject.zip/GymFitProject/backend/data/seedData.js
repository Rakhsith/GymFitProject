const db = require('../config/db').getDb();

const seedData = {
  seed() {
    // Could add default demo data here if needed
    // Currently left minimal for clean install.
  }
};

module.exports = seedData;
