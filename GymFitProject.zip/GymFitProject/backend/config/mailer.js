const nodemailer = require('nodemailer');

// For production, use OAuth2 with Gmail or another provider.
// For university demo, you can temporarily enable "App password" on a Gmail account
// and use it here, OR use a fake SMTP like Mailtrap.
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GYM_FIT_EMAIL || 'gymfit.demo.gmail@gmail.com',
    pass: process.env.GYM_FIT_PASSWORD || 'app-password-or-demo'
  }
});

module.exports = transporter;
