const db = require('../config/db').getDb();

const WorkoutModel = {
  create(workout, cb) {
    const sql = `
      INSERT INTO workouts (user_id, name, muscle_group, difficulty, day_of_week, is_rest_day, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    db.run(
      sql,
      [
        workout.user_id,
        workout.name,
        workout.muscle_group || null,
        workout.difficulty || null,
        workout.day_of_week || null,
        workout.is_rest_day ? 1 : 0,
        workout.notes || null
      ],
      function (err) {
        if (err) return cb(err);
        cb(null, { id: this.lastID, ...workout });
      }
    );
  },

  update(id, workout, cb) {
    const sql = `
      UPDATE workouts
      SET name = ?, muscle_group = ?, difficulty = ?, day_of_week = ?, is_rest_day = ?, notes = ?
      WHERE id = ? AND user_id = ?
    `;
    db.run(
      sql,
      [
        workout.name,
        workout.muscle_group || null,
        workout.difficulty || null,
        workout.day_of_week || null,
        workout.is_rest_day ? 1 : 0,
        workout.notes || null,
        id,
        workout.user_id
      ],
      function (err) {
        if (err) return cb(err);
        cb(null, this.changes);
      }
    );
  },

  delete(id, userId, cb) {
    db.run('DELETE FROM workouts WHERE id = ? AND user_id = ?', [id, userId], function (err) {
      if (err) return cb(err);
      cb(null, this.changes);
    });
  },

  getByUser(userId, cb) {
    db.all('SELECT * FROM workouts WHERE user_id = ? ORDER BY created_at DESC', [userId], cb);
  }
};

module.exports = WorkoutModel;
