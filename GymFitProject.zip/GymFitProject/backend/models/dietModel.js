const db = require('../config/db').getDb();

const DietModel = {
  create(plan, cb) {
    const sql = `
      INSERT INTO diet_plans (user_id, goal, type, calories, protein_g, carbs_g, fats_g, plan_text)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    db.run(
      sql,
      [
        plan.user_id,
        plan.goal,
        plan.type,
        plan.calories,
        plan.protein_g,
        plan.carbs_g,
        plan.fats_g,
        plan.plan_text
      ],
      function (err) {
        if (err) return cb(err);
        cb(null, { id: this.lastID, ...plan });
      }
    );
  },

  getLatestByUser(userId, cb) {
    db.get(
      'SELECT * FROM diet_plans WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
      [userId],
      cb
    );
  }
};

module.exports = DietModel;
