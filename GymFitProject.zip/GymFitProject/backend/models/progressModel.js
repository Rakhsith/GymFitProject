const db = require('../config/db').getDb();

const ProgressModel = {
  create(entry, cb) {
    const sql = `
      INSERT INTO progress (user_id, date, weight_kg, notes)
      VALUES (?, ?, ?, ?)
    `;
    db.run(
      sql,
      [entry.user_id, entry.date, entry.weight_kg, entry.notes || null],
      function (err) {
        if (err) return cb(err);
        cb(null, { id: this.lastID, ...entry });
      }
    );
  },

  getByUser(userId, cb) {
    db.all(
      'SELECT * FROM progress WHERE user_id = ? ORDER BY date ASC',
      [userId],
      cb
    );
  }
};

module.exports = ProgressModel;
