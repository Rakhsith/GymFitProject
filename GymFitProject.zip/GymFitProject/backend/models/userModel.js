const db = require('../config/db').getDb();

const UserModel = {
  create(user, cb) {
    const sql = `
      INSERT INTO users (name, email, password_hash, gender, age, height_cm, weight_kg)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    db.run(
      sql,
      [
        user.name,
        user.email,
        user.password_hash,
        user.gender || null,
        user.age || null,
        user.height_cm || null,
        user.weight_kg || null
      ],
      function (err) {
        if (err) return cb(err);
        cb(null, { id: this.lastID, ...user });
      }
    );
  },

  findByEmail(email, cb) {
    db.get('SELECT * FROM users WHERE email = ?', [email], cb);
  },

  findById(id, cb) {
    db.get('SELECT * FROM users WHERE id = ?', [id], cb);
  }
};

module.exports = UserModel;
