const db = require('../config/db').getDb();

const FeedbackModel = {
  create(feedback, cb) {
    const sql = `
      INSERT INTO feedback (name, email, subject, message)
      VALUES (?, ?, ?, ?)
    `;
    db.run(
      sql,
      [feedback.name, feedback.email, feedback.subject, feedback.message],
      function (err) {
        if (err) return cb(err);
        cb(null, { id: this.lastID, ...feedback });
      }
    );
  }
};

module.exports = FeedbackModel;
