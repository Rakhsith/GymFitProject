const CalculatorService = require('../services/calculatorService');
const UserModel = require('../models/userModel');

function calculateAll(req, res) {
  const { weight_kg, height_cm, age, gender, activityLevel, goal } = req.body;

  const bmiData = CalculatorService.bmi(weight_kg, height_cm);
  const bmr = CalculatorService.bmr(gender, weight_kg, height_cm, age);
  const dailyCalories = CalculatorService.dailyCalories(bmr, activityLevel);
  const macros = CalculatorService.macros(dailyCalories, goal);

  res.json({
    bmi: bmiData,
    bmr,
    dailyCalories,
    macros
  });
}

function calculateForUser(req, res) {
  const userId = req.userId;

  UserModel.findById(userId, (err, user) => {
    if (err || !user) return res.status(404).json({ error: 'User not found' });

    const activityLevel = req.body.activityLevel || 'moderate';
    const goal = req.body.goal || 'maintenance';

    const bmiData = CalculatorService.bmi(user.weight_kg, user.height_cm);
    const bmr = CalculatorService.bmr(user.gender, user.weight_kg, user.height_cm, user.age);
    const dailyCalories = CalculatorService.dailyCalories(bmr, activityLevel);
    const macros = CalculatorService.macros(dailyCalories, goal);

    res.json({
      bmi: bmiData,
      bmr,
      dailyCalories,
      macros,
      user
    });
  });
}

module.exports = {
  calculateAll,
  calculateForUser
};
