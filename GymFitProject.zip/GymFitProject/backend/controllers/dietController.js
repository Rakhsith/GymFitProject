const DietService = require('../services/dietService');
const UserModel = require('../models/userModel');

function generatePlan(req, res) {
  UserModel.findById(req.userId, (err, user) => {
    if (err || !user) return res.status(404).json({ error: 'User not found' });

    const options = {
      goal: req.body.goal,
      type: req.body.type,
      activityLevel: req.body.activityLevel || 'moderate'
    };

    DietService.generatePlan(user, options, (err2, plan) => {
      if (err2) return res.status(400).json({ error: err2.message });
      res.json(plan);
    });
  });
}

function getLatest(req, res) {
  DietService.getLatest(req.userId, (err, plan) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!plan) return res.status(404).json({ error: 'No diet plan found' });
    res.json(plan);
  });
}

module.exports = {
  generatePlan,
  getLatest
};
