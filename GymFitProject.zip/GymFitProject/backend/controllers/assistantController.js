const AssistantService = require('../services/assistantService');

function chat(req, res) {
  const { message } = req.body;
  const reply = AssistantService.respond(message);
  res.json(reply);
}

module.exports = {
  chat
};
