const AuthService = require('../services/authService');

function register(req, res) {
  AuthService.register(req.body, (err, user) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'Registration successful', user });
  });
}

function login(req, res) {
  const { email, password } = req.body;
  AuthService.login(email, password, (err, data) => {
    if (err) return res.status(401).json({ error: err.message });
    res.json({
      token: data.token,
      user: {
        id: data.user.id,
        name: data.user.name,
        email: data.user.email,
        gender: data.user.gender,
        age: data.user.age,
        height_cm: data.user.height_cm,
        weight_kg: data.user.weight_kg
      }
    });
  });
}

function authMiddleware(req, res, next) {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ error: 'Missing auth header' });
  const token = header.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Missing token' });

  AuthService.verifyToken(token, (err, decoded) => {
    if (err) return res.status(401).json({ error: 'Invalid token' });
    req.userId = decoded.userId;
    next();
  });
}

module.exports = {
  register,
  login,
  authMiddleware
};
