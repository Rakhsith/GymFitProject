const ProgressService = require('../services/progressService');

function addEntry(req, res) {
  ProgressService.addEntry(req.userId, req.body, (err, entry) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json(entry);
  });
}

function listEntries(req, res) {
  ProgressService.getEntries(req.userId, (err, entries) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json(entries);
  });
}

module.exports = {
  addEntry,
  listEntries
};
