const FeedbackService = require('../services/feedbackService');

function submit(req, res) {
  FeedbackService.submit(req.body, (err, saved) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: 'Feedback sent successfully', feedback: saved });
  });
}

module.exports = {
  submit
};
