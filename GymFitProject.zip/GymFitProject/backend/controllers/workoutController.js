const WorkoutService = require('../services/workoutService');

function addWorkout(req, res) {
  WorkoutService.addWorkout(req.userId, req.body, (err, workout) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json(workout);
  });
}

function updateWorkout(req, res) {
  const id = req.params.id;
  WorkoutService.updateWorkout(req.userId, id, req.body, (err, changes) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!changes) return res.status(404).json({ error: 'Workout not found' });
    res.json({ message: 'Updated successfully' });
  });
}

function deleteWorkout(req, res) {
  const id = req.params.id;
  WorkoutService.deleteWorkout(req.userId, id, (err, changes) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!changes) return res.status(404).json({ error: 'Workout not found' });
    res.json({ message: 'Deleted successfully' });
  });
}

function listWorkouts(req, res) {
  WorkoutService.getWorkouts(req.userId, (err, workouts) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json(workouts);
  });
}

module.exports = {
  addWorkout,
  updateWorkout,
  deleteWorkout,
  listWorkouts
};
