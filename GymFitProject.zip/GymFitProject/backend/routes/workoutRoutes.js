const express = require('express');
const router = express.Router();
const workoutController = require('../controllers/workoutController');
const { authMiddleware } = require('../controllers/authController');

router.use(authMiddleware);
router.get('/', workoutController.listWorkouts);
router.post('/', workoutController.addWorkout);
router.put('/:id', workoutController.updateWorkout);
router.delete('/:id', workoutController.deleteWorkout);

module.exports = router;
