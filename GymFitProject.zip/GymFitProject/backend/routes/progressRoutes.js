const express = require('express');
const router = express.Router();
const progressController = require('../controllers/progressController');
const { authMiddleware } = require('../controllers/authController');

router.use(authMiddleware);

router.get('/', progressController.listEntries);
router.post('/', progressController.addEntry);

module.exports = router;
