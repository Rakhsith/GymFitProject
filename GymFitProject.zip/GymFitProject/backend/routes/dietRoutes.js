const express = require('express');
const router = express.Router();
const dietController = require('../controllers/dietController');
const { authMiddleware } = require('../controllers/authController');

router.use(authMiddleware);

router.get('/latest', dietController.getLatest);
router.post('/generate', dietController.generatePlan);

module.exports = router;
