const express = require('express');
const router = express.Router();
const calculatorController = require('../controllers/calculatorController');
const { authMiddleware } = require('../controllers/authController');

router.post('/anonymous', calculatorController.calculateAll);
router.post('/me', authMiddleware, calculatorController.calculateForUser);

module.exports = router;
