const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./config/db');
const seedData = require('./data/seedData');

// Add these routes (they were missing)
const authRoutes = require('./routes/authRoutes');
const calculatorRoutes = require('./routes/calculatorRoutes');
const workoutRoutes = require('./routes/workoutRoutes');
const progressRoutes = require('./routes/progressRoutes');
const dietRoutes = require('./routes/dietRoutes');
const assistantRoutes = require('./routes/assistantRoutes');
const feedbackRoutes = require('./routes/feedbackRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize DB and seed
db.init();
seedData.seed();

// API routes (3-tier via controllers & services)
app.use('/api/auth', authRoutes);
app.use('/api/calculators', calculatorRoutes);
app.use('/api/workouts', workoutRoutes);
app.use('/api/progress', progressRoutes);
app.use('/api/diet', dietRoutes);
app.use('/api/assistant', assistantRoutes);
app.use('/api/feedback', feedbackRoutes);

// Serve static frontend (optional, for simple setup)
app.use('/', express.static(path.join(__dirname, '..', 'frontend')));

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
