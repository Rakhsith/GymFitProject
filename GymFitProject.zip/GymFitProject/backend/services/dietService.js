const DietModel = require('../models/dietModel');
const CalculatorService = require('./calculatorService');

const DietService = {
  generatePlan(user, options, cb) {
    const { goal, type, activityLevel } = options;
    const bmr = CalculatorService.bmr(user.gender, user.weight_kg, user.height_cm, user.age);
    const dailyCalories = CalculatorService.dailyCalories(bmr, activityLevel);
    const macros = CalculatorService.macros(dailyCalories, goal);

    const planText = buildPlanText(goal, type, dailyCalories, macros);

    const plan = {
      user_id: user.id,
      goal,
      type,
      calories: dailyCalories,
      protein_g: macros.protein_g,
      carbs_g: macros.carbs_g,
      fats_g: macros.fats_g,
      plan_text: planText
    };

    DietModel.create(plan, cb);
  },

  getLatest(userId, cb) {
    DietModel.getLatestByUser(userId, cb);
  }
};

function buildPlanText(goal, type, calories, macros) {
  const veg = type === 'veg';
  const lines = [];

  lines.push(`Goal: ${goal.replace('_', ' ').toUpperCase()}`);
  lines.push(`Calories: ~${Math.round(calories)} kcal`);
  lines.push(
    `Macros: Protein ${macros.protein_g} g, Carbs ${macros.carbs_g} g, Fats ${macros.fats_g} g`
  );
  lines.push('');
  lines.push('Sample Day:');

  if (veg) {
    lines.push('- Breakfast: Oats with milk, nuts, and fruits.');
    lines.push('- Lunch: Brown rice, dal, mixed vegetable sabzi, salad.');
    lines.push('- Snack: Greek yogurt or paneer cubes, fruit.');
    lines.push('- Dinner: Whole wheat roti, tofu/paneer curry, vegetables.');
  } else {
    lines.push('- Breakfast: Eggs, whole grain toast, fruit.');
    lines.push('- Lunch: Grilled chicken, brown rice, vegetables, salad.');
    lines.push('- Snack: Yogurt, nuts, or protein shake.');
    lines.push('- Dinner: Fish/chicken, sweet potato, vegetables.');
  }

  lines.push('');
  lines.push('Hydration: 2–3 liters of water per day.');
  lines.push('Adjust portions based on progress every 2–3 weeks.');

  return lines.join('\n');
}

module.exports = DietService;
