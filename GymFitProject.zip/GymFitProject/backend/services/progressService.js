const ProgressModel = require('../models/progressModel');

const ProgressService = {
  addEntry(userId, data, cb) {
    const entry = {
      user_id: userId,
      date: data.date,
      weight_kg: data.weight_kg,
      notes: data.notes
    };
    ProgressModel.create(entry, cb);
  },

  getEntries(userId, cb) {
    ProgressModel.getByUser(userId, cb);
  }
};

module.exports = ProgressService;
