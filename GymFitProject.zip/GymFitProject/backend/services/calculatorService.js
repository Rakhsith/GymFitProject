const CalculatorService = {
  bmi(weightKg, heightCm) {
    const heightM = heightCm / 100;
    const bmi = weightKg / (heightM * heightM);
    let category = 'Normal';
    if (bmi < 18.5) category = 'Underweight';
    else if (bmi >= 25 && bmi < 30) category = 'Overweight';
    else if (bmi >= 30) category = 'Obese';
    return { bmi: parseFloat(bmi.toFixed(2)), category };
  },

  bmr(gender, weightKg, heightCm, age) {
    let bmr;
    if (gender === 'male') {
      bmr = 10 * weightKg + 6.25 * heightCm - 5 * age + 5;
    } else {
      bmr = 10 * weightKg + 6.25 * heightCm - 5 * age - 161;
    }
    return parseFloat(bmr.toFixed(2));
  },

  dailyCalories(bmr, activityLevel) {
    let factor = 1.2;
    if (activityLevel === 'light') factor = 1.375;
    else if (activityLevel === 'moderate') factor = 1.55;
    else if (activityLevel === 'active') factor = 1.725;
    else if (activityLevel === 'very_active') factor = 1.9;
    const calories = bmr * factor;
    return parseFloat(calories.toFixed(2));
  },

  macros(calories, goal) {
    let proteinPercent = 0.3;
    let carbsPercent = 0.4;
    let fatsPercent = 0.3;

    if (goal === 'weight_loss') {
      proteinPercent = 0.35;
      carbsPercent = 0.35;
      fatsPercent = 0.3;
    } else if (goal === 'muscle_gain') {
      proteinPercent = 0.35;
      carbsPercent = 0.45;
      fatsPercent = 0.2;
    }

    const protein = (calories * proteinPercent) / 4;
    const carbs = (calories * carbsPercent) / 4;
    const fats = (calories * fatsPercent) / 9;

    return {
      protein_g: parseFloat(protein.toFixed(1)),
      carbs_g: parseFloat(carbs.toFixed(1)),
      fats_g: parseFloat(fats.toFixed(1))
    };
  }
};

module.exports = CalculatorService;
