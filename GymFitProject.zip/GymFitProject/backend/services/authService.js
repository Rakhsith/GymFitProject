const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const UserModel = require('../models/userModel');

const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-key';
const SALT_ROUNDS = 10;

const AuthService = {
  register(data, cb) {
    UserModel.findByEmail(data.email, (err, existing) => {
      if (err) return cb(err);
      if (existing) return cb(new Error('Email already registered'));

      bcrypt.hash(data.password, SALT_ROUNDS, (hashErr, hash) => {
        if (hashErr) return cb(hashErr);

        const user = {
          name: data.name,
          email: data.email,
          password_hash: hash,
          gender: data.gender,
          age: data.age,
          height_cm: data.height_cm,
          weight_kg: data.weight_kg
        };

        UserModel.create(user, (createErr, createdUser) => {
          if (createErr) return cb(createErr);
          cb(null, createdUser);
        });
      });
    });
  },

  login(email, password, cb) {
    UserModel.findByEmail(email, (err, user) => {
      if (err) return cb(err);
      if (!user) return cb(new Error('Invalid credentials'));

      bcrypt.compare(password, user.password_hash, (cmpErr, isMatch) => {
        if (cmpErr) return cb(cmpErr);
        if (!isMatch) return cb(new Error('Invalid credentials'));

        const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
        cb(null, { token, user });
      });
    });
  },

  verifyToken(token, cb) {
    jwt.verify(token, JWT_SECRET, (err, decoded) => {
      if (err) return cb(err);
      cb(null, decoded);
    });
  }
};

module.exports = AuthService;
