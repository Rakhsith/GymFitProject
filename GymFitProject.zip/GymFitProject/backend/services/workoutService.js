const WorkoutModel = require('../models/workoutModel');

const WorkoutService = {
  addWorkout(userId, data, cb) {
    const workout = {
      user_id: userId,
      name: data.name,
      muscle_group: data.muscle_group,
      difficulty: data.difficulty,
      day_of_week: data.day_of_week,
      is_rest_day: data.is_rest_day,
      notes: data.notes
    };
    WorkoutModel.create(workout, cb);
  },

  updateWorkout(userId, id, data, cb) {
    const workout = {
      user_id: userId,
      name: data.name,
      muscle_group: data.muscle_group,
      difficulty: data.difficulty,
      day_of_week: data.day_of_week,
      is_rest_day: data.is_rest_day,
      notes: data.notes
    };
    WorkoutModel.update(id, workout, cb);
  },

  deleteWorkout(userId, id, cb) {
    WorkoutModel.delete(id, userId, cb);
  },

  getWorkouts(userId, cb) {
    WorkoutModel.getByUser(userId, cb);
  }
};

module.exports = WorkoutService;
