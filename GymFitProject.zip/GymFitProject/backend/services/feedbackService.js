const FeedbackModel = require('../models/feedbackModel');
const transporter = require('../config/mailer');

const FeedbackService = {
  submit(feedback, cb) {
    FeedbackModel.create(feedback, (err, saved) => {
      if (err) return cb(err);

      const mailOptions = {
        from: feedback.email,
        to: 'gymfit@gmail.com',
        subject: `[GymFit Feedback] ${feedback.subject}`,
        text: `
Name: ${feedback.name}
Email: ${feedback.email}

Message:
${feedback.message}
        `
      };

      transporter.sendMail(mailOptions, (mailErr) => {
        if (mailErr) return cb(mailErr);
        cb(null, saved);
      });
    });
  }
};

module.exports = FeedbackService;
