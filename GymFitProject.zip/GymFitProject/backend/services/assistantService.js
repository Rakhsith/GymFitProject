// Rule-based AI assistant to be "future AI/ML ready"
const AssistantService = {
  respond(message) {
    const text = (message || '').toLowerCase();

    if (text.includes('membership') || text.includes('price') || text.includes('plan')) {
      return membershipReply();
    }
    if (text.includes('workout') || text.includes('exercise') || text.includes('schedule')) {
      return workoutReply();
    }
    if (text.includes('diet') || text.includes('food') || text.includes('meal')) {
      return dietReply();
    }
    if (text.includes('time') || text.includes('open') || text.includes('close')) {
      return timingReply();
    }
    if (text.includes('rule') || text.includes('dress') || text.includes('etiquette')) {
      return rulesReply();
    }
    if (text.includes('navigate') || text.includes('where') || text.includes('how to use')) {
      return navigationReply();
    }

    return genericReply();
  }
};

function membershipReply() {
  return {
    type: 'membership',
    message:
      'We offer Basic, Pro, and Elite membership plans. Basic is ideal for beginners (gym access + standard equipment). Pro adds group classes and trainer support. Elite includes personal coaching and advanced analytics. Ask for details on any plan.'
  };
}

function workoutReply() {
  return {
    type: 'workout',
    message:
      'For most members, a 4–5 day split works well. Example: Push (chest/shoulders/triceps), Pull (back/biceps), Legs, Full body or active rest. Always schedule at least 1–2 rest days per week and start each session with a warm-up.'
  };
}

function dietReply() {
  return {
    type: 'diet',
    message:
      'Focus on whole foods: lean protein, complex carbs, healthy fats, and plenty of vegetables. For weight loss, aim for a mild calorie deficit. For muscle gain, add a small surplus and keep protein high (roughly 1.6–2.2 g per kg of body weight).'
  };
}

function timingReply() {
  return {
    type: 'timing',
    message:
      'Typical gym timings are 5:30 AM – 10:00 PM on weekdays and 6:30 AM – 9:00 PM on weekends. Check with your local branch for holiday schedules and special class timings.'
  };
}

function rulesReply() {
  return {
    type: 'rules',
    message:
      'Core gym rules: carry a towel, wipe equipment after use, re-rack weights, wear proper shoes, avoid dropping weights, and respect others’ space. For safety, use a spotter on heavy lifts and follow trainer instructions.'
  };
}

function navigationReply() {
  return {
    type: 'navigation',
    message:
      'Use the sidebar to navigate: Dashboard gives an overview, Calculators handle BMI/BMR, Diet shows your personalized meal plan, Workouts manages your weekly schedule, Progress tracks weight history, Assistant answers questions, and Feedback lets you contact the team.'
  };
}

function genericReply() {
  return {
    type: 'generic',
    message:
      'Hi! I am your GymFit virtual assistant. You can ask me about membership plans, workout schedules, diet recommendations, gym timings & rules, or how to use different parts of this platform.'
  };
}

module.exports = AssistantService;
