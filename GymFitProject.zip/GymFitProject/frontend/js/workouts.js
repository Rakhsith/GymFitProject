requireAuth();
initUserChip();

const workoutForm = document.getElementById('workoutForm');
const workoutList = document.getElementById('workoutList');
const workoutIdInput = document.getElementById('workoutId');
const submitBtn = document.getElementById('workoutSubmitBtn');
const resetBtn = document.getElementById('workoutResetBtn');

async function loadWorkouts() {
  try {
    const workouts = await apiRequest('/workouts', { method: 'GET' });
    renderWorkouts(workouts);
  } catch (err) {
    console.error(err);
  }
}

function renderWorkouts(list) {
  workoutList.innerHTML = '';
  list.forEach((w) => {
    const div = document.createElement('div');
    div.className = 'workout-item';
    const left = document.createElement('div');
    left.innerHTML = `<strong>${w.day_of_week}</strong> • ${
      w.is_rest_day ? 'Rest day' : w.name
    }<div class="workout-meta">${w.muscle_group || ''} ${
      w.difficulty ? '• ' + w.difficulty : ''
    }</div>`;
    const actions = document.createElement('div');
    actions.className = 'workout-actions';
    const editBtn = document.createElement('button');
    editBtn.className = 'btn outline small';
    editBtn.textContent = 'Edit';
    editBtn.onclick = () => fillForm(w);
    const delBtn = document.createElement('button');
    delBtn.className = 'btn outline small';
    delBtn.textContent = 'Delete';
    delBtn.onclick = () => deleteWorkout(w.id);
    actions.appendChild(editBtn);
    actions.appendChild(delBtn);
    div.appendChild(left);
    div.appendChild(actions);
    workoutList.appendChild(div);
  });
}

function fillForm(w) {
  workoutIdInput.value = w.id;
  document.getElementById('workoutName').value = w.name;
  document.getElementById('workoutMuscle').value = w.muscle_group || '';
  document.getElementById('workoutDifficulty').value = w.difficulty || 'Beginner';
  document.getElementById('workoutDay').value = w.day_of_week || 'Monday';
  document.getElementById('workoutRest').checked = !!w.is_rest_day;
  document.getElementById('workoutNotes').value = w.notes || '';
  submitBtn.textContent = 'Update Workout';
}

function resetForm() {
  workoutIdInput.value = '';
  workoutForm.reset();
  submitBtn.textContent = 'Add Workout';
}

async function deleteWorkout(id) {
  if (!confirm('Delete this workout?')) return;
  try {
    await apiRequest('/workouts/' + id, { method: 'DELETE' });
    loadWorkouts();
  } catch (err) {
    alert(err.message);
  }
}

workoutForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    name: document.getElementById('workoutName').value.trim(),
    muscle_group: document.getElementById('workoutMuscle').value.trim(),
    difficulty: document.getElementById('workoutDifficulty').value,
    day_of_week: document.getElementById('workoutDay').value,
    is_rest_day: document.getElementById('workoutRest').checked,
    notes: document.getElementById('workoutNotes').value.trim()
  };
  const id = workoutIdInput.value;
  try {
    if (id) {
      await apiRequest('/workouts/' + id, { method: 'PUT', body: payload });
    } else {
      await apiRequest('/workouts', { method: 'POST', body: payload });
    }
    resetForm();
    loadWorkouts();
  } catch (err) {
    alert(err.message);
  }
});

resetBtn.addEventListener('click', resetForm);

document.addEventListener('DOMContentLoaded', loadWorkouts);
