requireAuth();
initUserChip();

let weightChartInstance;

async function loadDashboard() {
  try {
    const user = getUser();
    if (user && user.height_cm && user.weight_kg && user.age && user.gender) {
      const calc = await apiRequest('/calculators/me', {
        method: 'POST',
        body: { activityLevel: 'moderate', goal: 'maintenance' }
      });
      document.getElementById('kpiBmi').textContent = calc.bmi.bmi;
      document.getElementById('kpiBmiCategory').textContent = calc.bmi.category;
      document.getElementById('kpiCalories').textContent = Math.round(calc.dailyCalories);
    }

    const workouts = await apiRequest('/workouts', { method: 'GET' });
    document.getElementById('kpiWorkouts').textContent = workouts.length;

    const weeklyEl = document.getElementById('weeklyList');
    weeklyEl.innerHTML = '';
    const days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
    days.forEach((day) => {
      const sameDay = workouts.filter((w) => w.day_of_week === day);
      const li = document.createElement('li');
      if (!sameDay.length) {
        li.textContent = `${day}: Rest / No workout`;
      } else {
        const labels = sameDay
          .map((w) => (w.is_rest_day ? 'Rest day' : w.name))
          .join(', ');
        li.textContent = `${day}: ${labels}`;
      }
      weeklyEl.appendChild(li);
    });

    const progress = await apiRequest('/progress', { method: 'GET' });
    const labels = progress.map((p) => p.date);
    const values = progress.map((p) => p.weight_kg);

    const ctx = document.getElementById('weightChart');
    if (ctx) {
      if (weightChartInstance) {
        weightChartInstance.destroy();
      }
      weightChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels,
          datasets: [
            {
              label: 'Weight (kg)',
              data: values,
              borderColor: '#22c55e',
              backgroundColor: 'rgba(34,197,94,0.15)',
              tension: 0.3
            }
          ]
        },
        options: {
          plugins: {
            legend: { display: false }
          },
          scales: {
            x: { display: true },
            y: { display: true }
          }
        }
      });
    }
  } catch (err) {
    console.error(err);
  }
}

document.addEventListener('DOMContentLoaded', loadDashboard);
