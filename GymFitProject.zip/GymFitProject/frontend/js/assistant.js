requireAuth();
initUserChip();

const chatWindow = document.getElementById('chatWindow');
const chatForm = document.getElementById('chatForm');
const chatInput = document.getElementById('chatInput');

function appendMessage(text, from) {
  const div = document.createElement('div');
  div.className = 'chat-message ' + from;
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.textContent = text;
  div.appendChild(bubble);
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  appendMessage(text, 'user');
  chatInput.value = '';
  try {
    const reply = await apiRequest('/assistant/chat', {
      method: 'POST',
      body: { message: text }
    });
    appendMessage(reply.message, 'bot');
  } catch (err) {
    appendMessage('Sorry, something went wrong: ' + err.message, 'bot');
  }
});
