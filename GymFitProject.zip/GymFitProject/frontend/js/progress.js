requireAuth();
initUserChip();

let progressChartInstance;

async function loadProgress() {
  try {
    const entries = await apiRequest('/progress', { method: 'GET' });
    renderTable(entries);
    renderChart(entries);
  } catch (err) {
    console.error(err);
  }
}

function renderTable(entries) {
  const tbody = document.getElementById('progressTableBody');
  tbody.innerHTML = '';
  entries.forEach((e) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${e.date}</td><td>${e.weight_kg}</td><td>${e.notes || ''}</td>`;
    tbody.appendChild(tr);
  });
}

function renderChart(entries) {
  const labels = entries.map((e) => e.date);
  const values = entries.map((e) => e.weight_kg);
  const ctx = document.getElementById('progressChart');
  if (!ctx) return;
  if (progressChartInstance) {
    progressChartInstance.destroy();
  }
  progressChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: 'Weight (kg)',
          data: values,
          borderColor: '#38bdf8',
          backgroundColor: 'rgba(56,189,248,0.15)',
          tension: 0.3
        }
      ]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: { x: { display: true }, y: { display: true } }
    }
  });
}

const progressForm = document.getElementById('progressForm');
progressForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    date: document.getElementById('progressDate').value,
    weight_kg: Number(document.getElementById('progressWeight').value),
    notes: document.getElementById('progressNotes').value.trim()
  };
  try {
    await apiRequest('/progress', { method: 'POST', body: payload });
    progressForm.reset();
    loadProgress();
  } catch (err) {
    alert(err.message);
  }
});

document.addEventListener('DOMContentLoaded', loadProgress);
