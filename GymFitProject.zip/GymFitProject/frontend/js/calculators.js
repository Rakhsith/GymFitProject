requireAuth();
initUserChip();

const calcForm = document.getElementById('calcForm');

if (calcForm) {
  calcForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      gender: document.getElementById('gender').value,
      age: Number(document.getElementById('age').value),
      height_cm: Number(document.getElementById('height').value),
      weight_kg: Number(document.getElementById('weight').value),
      activityLevel: document.getElementById('activityLevel').value,
      goal: document.getElementById('goal').value
    };

    try {
      const data = await apiRequest('/calculators/anonymous', {
        method: 'POST',
        body: payload
      });
      document.getElementById('resBmi').textContent = data.bmi.bmi;
      document.getElementById('resBmiCat').textContent = data.bmi.category;
      document.getElementById('resBmr').textContent = data.bmr;
      document.getElementById('resCalories').textContent = Math.round(
        data.dailyCalories
      );
      document.getElementById('resProtein').textContent = data.macros.protein_g;
      document.getElementById('resCarbs').textContent = data.macros.carbs_g;
      document.getElementById('resFats').textContent = data.macros.fats_g;
    } catch (err) {
      alert(err.message);
    }
  });
}
