const API_BASE = 'http://localhost:5000/api';

function getToken() {
  return localStorage.getItem('gymfit_token');
}

function setSession(token, user) {
  localStorage.setItem('gymfit_token', token);
  localStorage.setItem('gymfit_user', JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem('gymfit_token');
  localStorage.removeItem('gymfit_user');
}

function getUser() {
  const raw = localStorage.getItem('gymfit_user');
  return raw ? JSON.parse(raw) : null;
}

async function apiRequest(path, options = {}) {
  const token = getToken();
  const headers = options.headers || {};
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  if (token) {
    headers['Authorization'] = 'Bearer ' + token;
  }
  const resp = await fetch(API_BASE + path, {
    ...options,
    headers,
    body:
      options.body && !(options.body instanceof FormData)
        ? JSON.stringify(options.body)
        : options.body
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    const errMsg = data.error || 'Request failed';
    throw new Error(errMsg);
  }
  return data;
}

function requireAuth() {
  if (!getToken()) {
    window.location.href = 'login.html';
  }
}

function initUserChip() {
  const user = getUser();
  const el = document.getElementById('userChip');
  if (user && el) {
    el.textContent = `${user.name} • ${user.email}`;
  }
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.onclick = () => {
      clearSession();
      window.location.href = 'login.html';
    };
  }
}
