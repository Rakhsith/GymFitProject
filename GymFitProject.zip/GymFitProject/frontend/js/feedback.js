requireAuth();
initUserChip();

const fbForm = document.getElementById('feedbackForm');
const fbStatus = document.getElementById('fbStatus');

fbForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    name: document.getElementById('fbName').value.trim(),
    email: document.getElementById('fbEmail').value.trim(),
    subject: document.getElementById('fbSubject').value.trim(),
    message: document.getElementById('fbMessage').value.trim()
  };
  fbStatus.textContent = 'Sending...';
  try {
    await apiRequest('/feedback', { method: 'POST', body: payload });
    fbStatus.textContent = 'Feedback sent successfully.';
    fbForm.reset();
  } catch (err) {
    fbStatus.textContent = 'Error: ' + err.message;
  }
});
