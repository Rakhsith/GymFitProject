// Login
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const errorEl = document.getElementById('loginError');
    errorEl.textContent = '';

    try {
      const data = await apiRequest('/auth/login', {
        method: 'POST',
        body: { email, password }
      });
      setSession(data.token, data.user);
      window.location.href = 'dashboard.html';
    } catch (err) {
      errorEl.textContent = err.message;
    }
  });
}

// Register
const registerForm = document.getElementById('registerForm');
if (registerForm) {
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      name: document.getElementById('name').value.trim(),
      email: document.getElementById('email').value.trim(),
      password: document.getElementById('password').value,
      gender: document.getElementById('gender').value,
      age: Number(document.getElementById('age').value) || null,
      height_cm: Number(document.getElementById('height').value) || null,
      weight_kg: Number(document.getElementById('weight').value) || null
    };
    const errorEl = document.getElementById('registerError');
    errorEl.textContent = '';

    try {
      await apiRequest('/auth/register', {
        method: 'POST',
        body: payload
      });
      window.location.href = 'login.html';
    } catch (err) {
      errorEl.textContent = err.message;
    }
  });
}
