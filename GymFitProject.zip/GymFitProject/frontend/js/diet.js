requireAuth();
initUserChip();

async function loadDiet() {
  try {
    const plan = await apiRequest('/diet/latest', { method: 'GET' });
    renderPlan(plan);
  } catch (err) {
    document.getElementById('dietMeta').textContent = 'No plan generated yet.';
    document.getElementById('dietText').textContent = '';
  }
}

function renderPlan(plan) {
  const meta = `Goal: ${plan.goal} • Type: ${plan.type} • Calories: ~${Math.round(
    plan.calories
  )} kcal`;
  document.getElementById('dietMeta').textContent = meta;
  document.getElementById('dietText').textContent = plan.plan_text;
}

const dietForm = document.getElementById('dietForm');
dietForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    goal: document.getElementById('dietGoal').value,
    type: document.getElementById('dietType').value,
    activityLevel: document.getElementById('dietActivity').value
  };
  try {
    const plan = await apiRequest('/diet/generate', {
      method: 'POST',
      body: payload
    });
    renderPlan(plan);
  } catch (err) {
    alert(err.message);
  }
});

document.addEventListener('DOMContentLoaded', loadDiet);
